package apiHub.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiHubApplication.class, args);
	}

}
